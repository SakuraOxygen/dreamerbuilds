/*:
*
* @plugindesc Ritter's Title Movie v1.0
*
* @author Ritter
*
* @help
*
* Ritter's Title Movie Plugin plays an intro movie before the Title Screen!
* The intro movie can be skipped by pressing ok/cancel buttons.
* The developer also has the option to allow for the intro movie to play
* if the player is idle on the title screen for a set amount of time, this
* time is configured within the plugin parameters.
* Cancel the transition from Title Screen to Intro Video with the press of a button!
*
* Place your movie files inside your projects movies folder. You will need both
* .webm and .mp4 files.
*
* If using MadeWithMV.js plugin place this plugin below MadeWithMV plugin in the 
* plugin manager for compatibility.
*
* --------------------------------------------------------------------------------
* 
* Terms of Use:
* Can be used in Commercial and Non-Commercial games if purchased.
* Personal edits are allowed for use in your game,
* don't claim credit for this plugin.
* Don't post this plugin elsewhere, modified or otherwise.
* Don't remove my name from @Author.
* I am not liable for any problems you may encounter while
* using this plugin, though I may, or may not, be available
* for support on RPG Maker Forums or my itch.io page for this plugin.
* I will not support edits to the code.
* Please credit me in your games credits as: Craig "Ritter" B.
*
* --------------------------------------------------------------------------------
*
* @param Title Movie Name
* @type string
* @desc The name of your title movie. Do not include file extension. Example: TheMovie
*
* @param Title Screen Idle Duration
* @type number
* @default 120
* @min -1
* @desc Time in seconds to wait for movie to play when player is idle. Set to -1 to disable Idle Video Player.
*
* @param Title Screen Fade Speed
* @type number
* @default 3
* @desc The fade speed in seconds when transitioning from Title Screen to movie when player is idle.
* 
* @param Black Screen Duration
* @type number
* @default 1
* @desc The number of seconds to wait after Title screen fades to black before starting Title Movie.
* 
*
*/

var Imported = Imported || {};
Imported.Ritter_TitleMovie = true;

var Ritter = Ritter || {};
Ritter.Params = Ritter.Params || {};
var Liquidize = Liquidize || {};
// Parameters

var parameters = PluginManager.parameters('Ritter_TitleMovie');
Ritter.Params.MovieName = String(parameters["Title Movie Name"]);
Ritter.Params.TitleWait = Number(parameters["Title Screen Idle Duration"]);
Ritter.Params.TitleWait *= 60;
Ritter.Params.fadeSpeed = Number(parameters["Title Screen Fade Speed"]);
Ritter.Params.fadeSpeed = Ritter.Params.fadeSpeed * 60;
Ritter.Params.blackWait = Number(parameters["Black Screen Duration"]);
Ritter.Params.blackWait = Ritter.Params.blackWait * 60;

RitterTitleMovie = false;
RitterFadeOut = false;
RitterFadeTime = Ritter.Params.fadeSpeed;
RitterBlackWait = Ritter.Params.blackWait;
RitterTitleWait = Ritter.Params.TitleWait;

(function() {

Ritter_Graphics_onVideoEnd = Graphics._onVideoEnd;
Graphics._onVideoEnd = function() {
    Ritter_Graphics_onVideoEnd.call(this);
	if (SceneManager._scene instanceof Scene_TitleMovie) {
		RitterTitleWait = Ritter.Params.TitleWait;
		RitterFadeOut = false;
		RitterFadeTime = Ritter.Params.fadeSpeed;
		RitterBlackWait = Ritter.Params.blackWait;
		SceneManager.goto(Scene_Title);
	}
};

// TitleMovie Scene

function Scene_TitleMovie() {
	this.initialize.apply(this, arguments);
};

Scene_TitleMovie.prototype = Object.create(Scene_MenuBase.prototype);
Scene_TitleMovie.prototype.constructor = Scene_TitleMovie;

Scene_TitleMovie.prototype.initialize = function() {
	Scene_MenuBase.prototype.initialize.call(this);        
	var name = Ritter.Params.MovieName;
	if (name.length > 0) {
		var ext = Ritter.videoFileExt();
		Graphics.playVideo('movies/' + name + ext);
	}
};

Scene_TitleMovie.prototype.update = function () {
	if (Graphics.isVideoPlaying() && (Input.isTriggered('ok')
								  || Input.isTriggered('menu')
								  || Input.isTriggered('cancel')
								  || Input.isTriggered('escape')
								  || TouchInput.isCancelled()
								  || TouchInput.isTriggered())) {
	Graphics._video.pause();
	Graphics._onVideoEnd();
	}
	if (Graphics.isVideoPlaying() && RitterTitleMovie == true) {
		Ritter.drawText();
	}
};

Ritter.drawText = function() {
	
};

Ritter.videoFileExt = function() {
	if (Graphics.canPlayVideoType('video/webm') && !Utils.isMobileDevice()) {
		return '.webm';
	} else {
		return '.mp4';
	}
};

var Ritter_SceneManager_goto = SceneManager.goto;
SceneManager.goto = function(sceneClass) {
	if (sceneClass === Scene_Title && RitterTitleMovie == false) {
		this._nextScene = new Scene_TitleMovie();
		RitterTitleMovie = true;
	} else {
		Ritter_SceneManager_goto.call(this, sceneClass);
	}
};

Ritter_Scene_Title_update = Scene_Title.prototype.update;
Scene_Title.prototype.update = function() {
	if (TouchInput.isTriggered() || TouchInput.isCancelled()) {
		RitterFadeOut ? Ritter.cancelTitleFade() : RitterTitleWait = Ritter.Params.TitleWait;
	}
	if (RitterTitleWait > 0) RitterTitleWait -= 1;
	if (RitterTitleWait == 0) {
		if (RitterFadeOut === false) {
			RitterFadeOut = true;
			this.fadeOutAll();
		}
		if (RitterFadeTime > 0) RitterFadeTime -= 1;
		if (RitterFadeTime == 0) {
			if (RitterBlackWait > 0) RitterBlackWait -= 1;
			if (RitterBlackWait == 0) {
			SceneManager.goto(Scene_TitleMovie);
			$gameScreen.startFadeIn(0);
			}
		}
	}
	if (Graphics._video.ended !== true) Graphics._video.pause();
	Ritter_Scene_Title_update.call(this);
};

var Ritter_Scene_Base_fadeOutAll = Scene_Base.prototype.fadeOutAll;
Scene_Base.prototype.fadeOutAll = function() {
	if (RitterFadeOut == true) {
		var time = Ritter.Params.fadeSpeed / 60;
		AudioManager.fadeOutBgm(time);
		AudioManager.fadeOutBgs(time);
		AudioManager.fadeOutMe(time);
		this.startFadeOut(Ritter.Params.fadeSpeed);
	} else {
		Ritter_Scene_Base_fadeOutAll.call(this);
	}
};

// Refresh Title Screen idle timer on player activity

var Ritter_Input_isTriggered = Input.isTriggered;
Input.isTriggered = function(keyName) {
	if (SceneManager._scene instanceof Scene_Title && (keyName == 'up'
												   || keyName == 'down'
												   || keyName == 'left'
												   || keyName == 'right'
												   || keyName == 'escape'
												   || keyName == 'cancel'
												   || keyName == 'menu')) {
		RitterTitleWait = Ritter.Params.TitleWait;
		if (RitterFadeOut == true) {
			Ritter.cancelTitleFade();
		}
	}
	return Ritter_Input_isTriggered.call(this, keyName);
};

// Cancel Transition from Title Screen to Intro Movie on 'ok'

var Ritter_Window_TitleCommand_processOk = Window_TitleCommand.prototype.processOk;
Window_TitleCommand.prototype.processOk = function() {
    if (RitterFadeOut == true) { 
		Ritter.cancelTitleFade();
	} else {
	Ritter_Window_TitleCommand_processOk.call(this);
	}
};

Ritter.cancelTitleFade = function() {
	SceneManager._scene.startFadeIn(0, false);
	AudioManager._bgmBuffer = Ritter._TitleSceneBuffer;
	AudioManager._currentBgm = Ritter._TitleSceneBgm;
	Ritter._bgm = AudioManager.saveBgm();
	Ritter._bgs = AudioManager.saveBgs();			
	var bgm = Ritter._bgm;
	var bgs = Ritter._bgs;
	if(!AudioManager.isCurrentBgm(Ritter._bgm)) {
		AudioManager.playBgm(Ritter._bgm);
	} else if(AudioManager._bgmBuffer) {
		AudioManager._bgmBuffer.play(true, bgm.pos);
	}
	if(!AudioManager.isCurrentBgs(Ritter._bgs)) {
		AudioManager.playBgs(Ritter._bgs);
	} else if(AudioManager._bgsBuffer) {
		AudioManager._bgsBuffer.play(true, bgs.pos);
	}
	RitterFadeOut = false;
	RitterFadeTime = Ritter.Params.fadeSpeed;
	RitterBlackWait = Ritter.Params.blackWait;
	RitterTitleWait = Ritter.Params.TitleWait;
};

// Audio Manager

var Ritter_AudioManager_fadeOutBgm = AudioManager.fadeOutBgm;
AudioManager.fadeOutBgm = function(duration) {
    if (SceneManager._scene instanceof Scene_Title) {
		if (this._bgmBuffer && this._currentBgm) {
		Ritter._TitleSceneBgm = this._currentBgm;
		Ritter._TitleSceneBuffer = this._bgmBuffer;
		this._bgmBuffer.fadeOut(duration);
		this._currentBgm = null;
		}
	} else {
		Ritter_AudioManager_fadeOutBgm.call(this,duration);
	}
};

// MadeWithMV plugin compatibility
// Lets overwrite this plugin to send us to the proper scene.
// In doing so lets place this plugin below MadeWithMV plugin
// in the plugin manager.


if (typeof Liquidize.MadeWithMV !== "undefined") {
    Scene_Splash.prototype.gotoTitleOrTest = function() {
        Scene_Base.prototype.start.call(this);
        SoundManager.preloadImportantSounds();
        if (DataManager.isBattleTest()) {
            DataManager.setupBattleTest();
            SceneManager.goto(Scene_Battle);
        } else if (DataManager.isEventTest()) {
            DataManager.setupEventTest();
            SceneManager.goto(Scene_Map);
        } else {
			console.log("got here");
            this.checkPlayerLocation();
            DataManager.setupNewGame();
            SceneManager.goto(Scene_TitleMovie);
			RitterTitleMovie = true;
        }
        this.updateDocumentTitle();
    };
};

})();