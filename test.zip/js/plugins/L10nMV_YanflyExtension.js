/*:
 * @plugindesc This plugin provides localization feature to RPG Maker MV.
 * Version : Release 1.4.5
 * Commit hash : 0c92f246d3fc2572ec3086991f670ab278ec7856
 * @author Creta Park (https://creft.me/cretapark)
 *
 * @help
 * 
 * |                                                                  |
 * |              ===== L10nMV_YanflyExtension.js =====               |
 * |                                                                  |
 * | This plugin supports L10nMV to use YEP_OptionsCore plugin.       |
 * | Created by Creta Park (https://creft.me/cretapark)               |
 * | License : MIT                                                    |
 * | GitHub page : https://github.com/Creta5164/L10nMV.js             |
 * | Recommanded MV version : 1.6.2^                                  |
 * |                                                                  |
 * | - How to setup ------------------------------------------------- |
 * | 1. Add this plugin right after L10nMV in plugins list like this. |
 * | ---------------------------------------------------------------- |
 * | L10nMV                 | ON       | ...                          |
 * | L10nMV_YanflyExtension | ON       | ...                          |
 * | L10nMVEditor           | OFF      | ...                          |
 * | ...                    |          |                              |
 * | YEP_OptionsCore        | ON       | ...                          |
 * | ...                    |          |                              |
 * | ---------------------------------------------------------------- |
 * | 2. Also add whitelist this plugin to L10nMV and L10nMVEditor.    |
 * | 3. Open YEP_OptionsCore plugin settings.                         |
 * | 4. Goto Options Categories you want to add L10nMV option.        |
 * | 5. Create new option.                                            |
 * | 6. Setting up like below :                                       |
 * | ---------------------------------------------------------------- |
 * | Name : \i[4]{name}                                               |
 * | [-] ---Settings---                                               |
 * | Help Description : (Write description in project's language)     |
 * |           Symbol : L10nMV.LocalLanguage                          |
 * |        Show/Hide : show = true;                                  |
 * |           Enable : enabled = true;                               |
 * |              Ext : ext = 0;                                      |
 * | [-] ---Functions---                                              |
 * |    Make Option Code : L10nMV.OptionWindow_Create(this, name);    |
 * |    Draw Option Code : L10nMV.YanflyExt_DrawContent(this, index); |
 * |     Process OK Code : L10nMV.OptionWindow_CursorRight(this);     |
 * |   Cursor Right Code : L10nMV.OptionWindow_CursorRight(this);     |
 * |    Cursor Left Code : L10nMV.OptionWindow_CursorLeft(this);      |
 * | Default Config Code :                                            |
 * |    Save Config Code : L10nMV.CreateConfigData(config);           |
 * |    Load Config Code : L10nMV.ApplyFromConfig(config);            |
 * | ---------------------------------------------------------------- |
 * |                                                                  |
 */

if (typeof(L10nMV) === undefined)
    throw "Dependency 'L10nMV' not found.";

(function(){var d,e=L10nMV.OptionWindow_Create;L10nMV.OptionWindow_Create=function(a,c){d=c||"\\i[4]{name}";e.call(this,a)};L10nMV.YanflyExt_DrawContent=function(a,c){var b=a.itemRectForText(c);a.resetTextColor();a.changePaintOpacity(L10nMV.OptionWindow_IsEnabled());a.drawTextEx(d.replace("{name}",L10nMV.GetOptionText(L10nMV.ChangedLanguage)),b.x,b.y);a.drawText(L10nMV.Iso639_1Names[L10nMV.ChangedLanguage],b.width-a.statusWidth(),b.y,a.statusWidth(),"center")}})();