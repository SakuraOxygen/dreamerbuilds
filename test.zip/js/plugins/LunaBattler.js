/*=============================================================================
 * Luna Snippet: Adjust Battler Position
//=============================================================================
/*:
 * @plugindesc Adjust Battler Position
 * @author Visustella
 * 
*/

(function() {
    Sprite_Actor.prototype.setActorHome = function(index) {
        var ox = 700 + 80 * Math.floor(index / 2);
        var oy = 250 + 110 * (index % 2);

        // Actor 1
        if (index === 0) {
            x = ox
            y = oy
        } 
        // Actor 2
        if (index === 1) {
            x = ox + 100
            y = oy
        }
        // Actor 3
        if (index === 2) {
            x = ox + 110
            y = oy
        }
        // Actor 4
        if (index === 3) {
            x = ox + 230
            y = oy
        }

        this.setHome(x, y)
    }
})();
