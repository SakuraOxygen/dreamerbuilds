//==================================================================================
//=== TSR_Mirror === A Plugin by The Northern Frog =================================
//==================================================================================

var TSR = TSR || {};
TSR.mirror = TSR.mirror || {};
TSR.mirror.version = 1.09;

var Imported = Imported || {};
Imported.TSR_Mirror = true;

//==================================================================================

/*:
 * @target MZ
 * @plugindesc v1.0.9 Use map region Id or terrain tag to create floor or wall mirrors 
 *             that will reflect player, followers and events.
 * @author TSR, The Northern Frog, 2021      
 * @help 
 * =================================================================================
 * == About this Plugin ============================================================
 * =================================================================================
 * Use either map region Id or terrain tag to defines tiles as mirrors. These 
 * tiles will display the reflection of player, followers and events.
 * 
 * The reflection sprites are created bellow the tileset level, but above 
 * parallax level. That means the tiles you define as mirror should have 
 * a slightly decreased opacity so the reflection sprites can be seen
 * beneath. You can then add a parallax as a background for the mirrors.
 * 
 * The plugin provide 2 types of mirror tiles:
 * 
 *      Wall Mirrors:
 *         The reflection sprites are exact copy of the characters they 
 *         represent, and mirror their movements. When approaching the
 *         mirror, reflection first appear at top of the mirror, and as
 *         the character get nearer, it will move down to be just in front
 *         of the character when it is standing in front of the mirror.
 *
 *              Parameters
 *        ==========================================================
 *       X Offset = the horizontal offset of the reflection sprite.
 * 
 *       Y Offset = the vertical offset of the reflection sprite.
 * 
 * 
 * 
 *      Floor Mirrors:
 *         The reflection sprite can have a little blur filter and a 
 *         small angulation. They always stick slightly to a fixed 
 *         position relatives to the character they represent. The
 *         floor mirrors settings are managed by plugin parameters.
 * 
 *              Parameters
 *        ==========================================================
 *       X Offset = the horizontal offset of the reflection sprite,
 *                  relative to the character. 
 * 
 *       Y Offset = the vertical offset of the reflection sprite,
 *                  relative to the character.
 * 
 *          Angle = the angle of the reflection sprite rotation. Set it
 *                  to 0 for no rotation or 2 to flip the sprite upside
 *                  down. Float values can be used.
 * 
 *           Blur = the strenght of the blur effect on the reflection
 *                  sprite. Set it to 0 for no blur.
 * 
 *       Opactity = the opacity of the reflection sprite ranging from
 *                  0 (invisible) to 255 (full opacity).
 * 
 *          Pulse = enable a slight pulsating effect on the reflection
 *                  sprite to mimic water movement.
 * 
 * 
 * 
 *  HOW TO USE:
 * 
 *         1) Select the tiles on your tileset that you want to act
 *            as mirror. Make the part of the tile where reflection 
 *            should appear semi-transparent (50-75% opacity).
 *  
 *         2) Set the Plugin parameters and choose map region Id or
 *            terrain tag to mark the mirror tiles.
 * 
 *         3) Place the mirror tiles on you map and mark them with the
 *            id you selected in the parameters. Make sure there's no
 *            other layers bellow the mirror tiles, because the reflection
 *            sprites appears beneath all tiles layer.
 * 
 * 
 * 
 *  EVENT COMMENT TAG:
 *          Use the following Event Comment Tag to prevent reflection of
 *          an event page.
 * 
 *                               <NO MIRROR>
 * 
 * 
 *          Those comment tags can be used to assign specific offset to
 *          an event reflection on wall or floor.
 * 
 *                         <WALL MIRROR OFFSET: X, Y>
 * 
 *                        <FLOOR MIRROR OFFSET: X, Y>
 * 
 * 
 * 
 *  MAP NOTE TAG:
 *          Use this notetag in a map notebox to turn map region Id into
 *          floor mirror. These floor mirrors will use the setting defined
 *          by the notetag instead of those set in the parameters. You
 *          can put more than one notetag in a map notebox to add more 
 *          floor mirror region Id with different settings.
 * 
 *       <FLOOR MIRROR INFO: regionId, x, y, angle, blur, opacity, pulse>
 * 
 *       regionId = the map region Id that is turned into a floor mirror
 *                  with the settings defined by the following arguments. 
 *              x = the horizontal offset of the reflection sprite,
 *                  relative to the character. 
 *              y = the vertical offset of the reflection sprite,
 *                  relative to the character. 
 *          angle = the angle of the reflection sprite rotation. Set it
 *                  to 0 for no rotation or 2 to flip the sprite upside
 *                  down. Float values can be used.
 *           blur = the strenght of the blur effect on the reflection
 *                  sprite. Set it to 0 for no blur.
 *       opactity = the opacity of the reflection sprite ranging from
 *                  0 (invisible) to 255 (full opacity).
 *          pulse = enable a slight pulsating effect on the reflection
 *                  sprite to mimic water movement.
 *
 * 
 *          MIRROR BACKGROUND
 *          =================
 *          Use the following map notetag to draw an image from the /img/
 *          parallaxes folder of your game, and use it as background for
 *          your mirroring areas. You can use images of any size and set
 *          as many mirror background as you need.
 * 
 *              <**LABEL** MIRROR BACKGROUND: filename, x, y, z> 
 * 
 *      **LABEL** = the label or name of the notatag. You can name it as
 *                  you want, but be sure that it is followed by the key
 *                  words 'mirror background'. If you use more than one
 *                  notetag, each must have a different name, of course.
 *              x = the map tile X of the left border of your background
 *                  image. You can use float number.
 *              y = the map tile Y of the top border of your background
 *                  image. You can use float numbers.
 *              z = the z index of your background image. You can use
 *                  float numbers.
 * 
 *                **Wall reflection sprites have a z index of -0.5 and 
 *                  floor reflection sprites have a z index between -0.6
 *                  and -0.8. Use z values bellow the reflection sprites
 *                  for you background images.
 *                  
 *  
 * 
 * =======================================================================================
 * == Term of Usage ======================================================================
 * =======================================================================================
 * 
 * Use in any independant RPG Maker MZ or MV projects, including commercials.
 *
 * Credit is required for using this Plugin. 
 * For crediting, use 'TSR' along with one of
 * the following terms: 
 *      'The Northern Frog' or 'A frog from the north'
 * 
 * Do not change the Header or the Terms of usage.
 *
 * DO NOT REDISTRIBUTE!
 * If you want to share it, share the link to my itch.io account: 
 * https://the-northern-frog.itch.io/
 * 
 *
 * =======================================================================================
 * == Version and compatibility ==========================================================
 * =======================================================================================
 * 2021/02/15 completed plugin, v1.0.0
 * 2021/02/18 small fix on wall mirror functions, v1.0.1
 * 2021/02/20 fix wall and floor mirror reflection position delay, v1.0.2
 * 2021/02/21 fix bug due to previous update, v1.0.3
 * 2021/02/21 add parameters for floor mirrors settings, v1.0.4
 * 2021/03/14 add the regionId argument to the map notetag, v1.0.5
 * 2021/03/17 fix reflection for event with image from tile sheet, v1.0.6
 * 2021/03/18 fix compatibility with TSR_MoveEvent, v1.0.7
 * 2021/03/19 add wall and floor mirrors offset event comment tag, v1.0.8
 * 2021/03/22 add mirror background image map notetag, v1.0.9
 * 
 * This plugin should be installed bellow TSR_MoveEvent for optimal compatibility
 * 
 * =======================================================================================
 * == END ================================================================================                                             
 * =======================================================================================
 *
 *                              "Have fun!"
 *                                                  TSR, The Northern Frog
 *
 * =======================================================================================
 *
 * 
 * @param ---Wall Mirror---
 *
 * @param Wall Mirror Id Type
 * @parent ---Wall Mirror---
 * @type combo
 * @option region id
 * @option tag
 * @desc Use map region Id or terrain tag to mark wall mirrors?
 * @default region id
 * 
 * @param Wall Mirror Region Id
 * @parent ---Wall Mirror---
 * @type Number
 * @min 1
 * @max 255
 * @desc Set the map region Id for wall mirror.
 * @default 253
 * 
 * @param Wall Mirror Terrain Tag
 * @parent ---Wall Mirror---
 * @type Number
 * @min 1
 * @max 7
 * @desc Set the terrain tag for wall mirror.
 * @default 5
 * 
 * @param Wall Mirror X Offset
 * @parent ---Wall Mirror---
 * @desc Set the horizontal offset of the reflection sprites.
 * @default 0
 * 
 * @param Wall Mirror Y Offset
 * @parent ---Wall Mirror---
 * @desc Set the vertical offset of the reflection sprites.
 * @default 0
 * 
 * 
 * @param ---Floor Mirror---
 *
 * @param Floor Mirror Id Type
 * @parent ---Floor Mirror---
 * @type combo
 * @option region id
 * @option tag
 * @desc Use map region Id or terrain tag to mark floor mirrors?
 * @default Region Id
 * 
 * @param Floor Mirror Region Id
 * @parent ---Floor Mirror---
 * @type Number
 * @min 1
 * @max 255
 * @desc Set the map region Id for floor mirror.
 * @default 254
 * 
 * @param Floor Mirror Terrain Tag
 * @parent ---Floor Mirror---
 * @type Number
 * @min 1
 * @max 7
 * @desc Set the terrain tag for floor mirror.
 * @default 6
 * 
 * @param Floor Mirror X Offset
 * @parent ---Floor Mirror---
 * @desc Set the horizontal offset of the reflection sprites.
 * @default 20
 * 
 * @param Floor Mirror Y Offset
 * @parent ---Floor Mirror---
 * @desc Set the vertical offset of the reflection sprites.
 * @default -56
 * 
 * @param Floor Mirror Angle
 * @parent ---Floor Mirror---
 * @desc Set the angle for the reflection sprite rotation.
 * @default 0.3
 *
 * @param Floor Mirror Blur
 * @parent ---Floor Mirror---
 * @desc Set the blur effect strenght of the reflection sprite.
 * @default 1
 * 
 * @param Floor Mirror Opacity
 * @parent ---Floor Mirror---
 * @type Number
 * @min 0
 * @max 255
 * @desc Set the opacity of the reflection sprite.
 * @default 200 
 *  
 * @param Floor Mirror Pulse
 * @parent ---Floor Mirror---
 * @type boolean
 * @on ON
 * @off OFF
 * @desc Enable the pulse effect for the reflection sprite?
 * OFF - false  ON - true
 * @default true
 * 
 *
 */

(() => {
const _0x44e8=['1373789InUZVS','1179752uoncMX','slice','Floor\x20Mirror\x20Y\x20Offset','needsMirror','_characterIndex','_spriteChar','_inFrontOfMirror','reflect','floor','filters','distBottom','checkReflectTiles','_visible','hasBitmap','_tileId','_scale','Wall\x20Mirror\x20Terrain\x20Tag','addMirrorBackground','_originalScaleY','_Game_Event_setupPage','isPickup','tilesetBitmap','_mirrorTag','_reflectInfo','55BugfyB','length','characterName','pullDist','createLowerLayer','unshift','start','regionId','setupPage','_wallOffsetY','addChild','setCurrentMirrorInfo','isFrontMirrorTile','_isPickable','1141081MOCUEv','_reflectTag','isMirrorColumn','Floor\x20Mirror\x20Blur','_displayY','code','_fixMirrorImage','parameters','visible','blur','checkMirrorEventTags','removeChild','screenY','Wall\x20Mirror\x20Region\x20Id','updateTileFrame','_needsReflect','1SWIgzs','isFrontOfMirror','_wallOffsetX','setInfo','create','updateMirrorSprites','_data','1376759jwkUSi','Wall\x20Mirror\x20Y\x20Offset','Floor\x20Mirror\x20Angle','anchor','getMapMirrorInfos','startMirror','prototype','29401DyckPf','currentMirrorInfo','preventReflect','tilesetNames','shift','createMirrorSprite','screenX','backDist','trim','Floor\x20Mirror\x20Opacity','_memberIndex','split','loadParallax','_opacity','_offsetY','_originalScaleX','setData','pickupEvent','match','checkMirrorTiles','Floor\x20Mirror\x20Region\x20Id','mirror','apply','needsReflect','initMembers','TSR_MoveEvent','note','push','_floorOffsetY','width','setupMirror','updateCharacterFrame','_mirrorMapId','canReflect','_angle','_filter','direction','bitmap','topMirrorY','_character','initialize','1190765UCHffP','loadTileset','_Spriteset_Map_createLowerLayer','setupReflect','_currentMirrorInfo','createMirrorBackGroundSprites','_mirrorSpriteSet','tag','update','tileId','scale','height','tileHeight','constructor','Floor\x20Mirror\x20X\x20Offset','roundXWithDirection','_preventMirror','_blur','page','MirrorBg','setFrame','setPreventReflect','followers','_bottomMirrorY','_Sprite_Character_initMembers','pattern','isPlayer','checkFixMirrorTag','_mirrorBGArray','_hasPickup','_needsMirror','checkCannotMirrorTag','1779771ImEHAU','inFrontOfMirror','setMirror','_characterName','_displayX','tilesetId','_realY','BlurFilter','_Sprite_Character_update','opacity','isTransparent','_grow','checkMapMirrorInfos','updateCharacterMove','indexOf','isPlaying','loadCharacter','characterIndex','updateMirrorBackground','_reflectMapId','getMapBackGround','_offsetX','_pulse','_floorMirrorOffset','_eventId','pushDist','distToBottomMirror','isHolding','1SZGZpZ','setReflect','tileset','Parameters','resetMirrorBottomTop','preventMirror','_cannotMirror','_tilesetId','isNearReflectTile','_reflectSpriteSet','_wallMirrorOffset','checkReflectY','setup','createReflectSprite','checkMirrorY','_frameCount','calcMirrorHeight','_floorOffsetX','_mirrorInfo','setPreventMirror','parent','Wall\x20Mirror\x20Id\x20Type','bottomMirrorY','1jbCZNB','_reflectId','Floor\x20Mirror\x20Pulse','_topMirrorY','call','tileWidth','_Spriteset_Map_update','canMirror','isPickupEvent'];const _0x2477=function(_0x1aa503,_0x5b88f2){_0x1aa503=_0x1aa503-0x1f1;let _0x44e882=_0x44e8[_0x1aa503];return _0x44e882;};const _0x262028=_0x2477;(function(_0x7c9a5b,_0x2285fb){const _0x81d240=_0x2477;while(!![]){try{const _0x1dcb1f=-parseInt(_0x81d240(0x284))+-parseInt(_0x81d240(0x21d))*-parseInt(_0x81d240(0x2a0))+-parseInt(_0x81d240(0x264))+parseInt(_0x81d240(0x2b7))*-parseInt(_0x81d240(0x234))+parseInt(_0x81d240(0x1f7))+-parseInt(_0x81d240(0x22d))*-parseInt(_0x81d240(0x1f6))+parseInt(_0x81d240(0x20f))*parseInt(_0x81d240(0x23b));if(_0x1dcb1f===_0x2285fb)break;else _0x7c9a5b['push'](_0x7c9a5b['shift']());}catch(_0x189e4d){_0x7c9a5b['push'](_0x7c9a5b['shift']());}}}(_0x44e8,0xeb71e),TSR['Parameters']=PluginManager['parameters']('TSR_Mirror'),TSR[_0x262028(0x250)]['_mirrorId']=String(TSR[_0x262028(0x2a3)][_0x262028(0x2b5)]),TSR['mirror'][_0x262028(0x25b)]=Number(TSR[_0x262028(0x2a3)][_0x262028(0x22a)]),TSR[_0x262028(0x250)][_0x262028(0x20d)]=Number(TSR['Parameters'][_0x262028(0x207)]),TSR['mirror']['_reflectId']=String(TSR['Parameters']['Floor\x20Mirror\x20Id\x20Type']),TSR[_0x262028(0x250)][_0x262028(0x297)]=Number(TSR[_0x262028(0x2a3)][_0x262028(0x24f)]),TSR[_0x262028(0x250)]['_reflectTag']=Number(TSR[_0x262028(0x2a3)]['Floor\x20Mirror\x20Terrain\x20Tag']),TSR[_0x262028(0x250)][_0x262028(0x230)]=function(_0x52f58a){const _0x387911=_0x262028;let _0x6da59=_0x52f58a===_0x387911(0x250)?TSR[_0x387911(0x250)]['_mirrorId']:TSR[_0x387911(0x250)][_0x387911(0x2b8)];if(_0x6da59===_0x387911(0x26b)){const _0x55d741=_0x52f58a===_0x387911(0x250)?TSR['mirror'][_0x387911(0x20d)]:TSR[_0x387911(0x250)][_0x387911(0x21e)];return['terrainTag',_0x55d741];}else{const _0x360a39=_0x52f58a==='mirror'?TSR['mirror']['_mirrorMapId']:TSR[_0x387911(0x250)][_0x387911(0x297)];return[_0x387911(0x216),_0x360a39];}},TSR[_0x262028(0x250)][_0x262028(0x2b2)]=TSR[_0x262028(0x250)][_0x262028(0x230)](_0x262028(0x250)),TSR['mirror'][_0x262028(0x20e)]=TSR[_0x262028(0x250)][_0x262028(0x230)](_0x262028(0x1fe)),TSR['mirror'][_0x262028(0x22f)]=parseInt(String(TSR[_0x262028(0x2a3)]['Wall\x20Mirror\x20X\x20Offset'])),TSR[_0x262028(0x250)][_0x262028(0x218)]=parseInt(String(TSR[_0x262028(0x2a3)][_0x262028(0x235)])),TSR[_0x262028(0x250)][_0x262028(0x2b1)]=parseInt(String(TSR[_0x262028(0x2a3)][_0x262028(0x272)])),TSR[_0x262028(0x250)][_0x262028(0x257)]=parseInt(String(TSR[_0x262028(0x2a3)][_0x262028(0x1f9)])),TSR['mirror'][_0x262028(0x25d)]=parseFloat(String(TSR[_0x262028(0x2a3)][_0x262028(0x236)])),TSR[_0x262028(0x250)][_0x262028(0x275)]=parseFloat(String(TSR[_0x262028(0x2a3)][_0x262028(0x220)])),TSR['mirror'][_0x262028(0x248)]=Number(TSR[_0x262028(0x2a3)][_0x262028(0x244)]),TSR[_0x262028(0x250)][_0x262028(0x29a)]=eval(String(TSR[_0x262028(0x2a3)][_0x262028(0x2b9)])),DataManager[_0x262028(0x298)]=function(){const _0x405b2b=_0x262028;if(!$dataMap)return 0x0;const _0x3e2902=/<(.*)(?:MIRROR BACKGROUND|MIRROR BACKGROUND):[ ]*(.*(?:\s*,\s*\d+)*)>/i,_0x2946dc=$dataMap[_0x405b2b(0x255)]['split'](/[\r\n]+/);let _0x2e4ba8=[];for(let _0x18809e=0x0;_0x18809e<_0x2946dc[_0x405b2b(0x210)];_0x18809e++){const _0x35be0f=_0x2946dc[_0x18809e]['toLowerCase']();if(_0x35be0f[_0x405b2b(0x24d)](_0x3e2902)){const _0x456c36=_0x2946dc[_0x18809e][_0x405b2b(0x1f8)](_0x2946dc[_0x18809e][_0x405b2b(0x292)]('<')+0x1,_0x2946dc[_0x18809e][_0x405b2b(0x292)]('mirror\x20background')),_0x5e02ff=_0x2946dc[_0x18809e][_0x405b2b(0x1f8)](_0x2946dc[_0x18809e][_0x405b2b(0x292)](':')+0x1,_0x2946dc[_0x18809e]['indexOf']('>'))[_0x405b2b(0x246)](',');_0x5e02ff[_0x405b2b(0x214)](_0x456c36),_0x2e4ba8[_0x405b2b(0x256)](_0x5e02ff);}}return _0x2e4ba8;},DataManager[_0x262028(0x238)]=function(_0x1069ee){const _0x5df3a6=_0x262028;if(!$dataMap)return 0x0;const _0x1484e0=/<(?:FLOOR MIRROR INFO|FLOOR MIRROR):[ ]*(.*(?:\s*,\s*\d+)*)>/i,_0x1fd8d9=$dataMap[_0x5df3a6(0x255)][_0x5df3a6(0x246)](/[\r\n]+/);for(let _0x394180=0x0;_0x394180<_0x1fd8d9['length'];_0x394180++){const _0x2da23f=_0x1fd8d9[_0x394180];if(_0x2da23f['match'](_0x1484e0)&&parseInt(RegExp['$1'])===_0x1069ee){const _0x9f6b31=_0x1fd8d9[_0x394180][_0x5df3a6(0x1f8)](_0x1fd8d9[_0x394180][_0x5df3a6(0x292)](':')+0x1,_0x1fd8d9[_0x394180][_0x5df3a6(0x292)]('>'))['split'](',');if(parseInt(_0x9f6b31[0x0])===_0x1069ee)return _0x9f6b31;}}return 0x0;},DataManager[_0x262028(0x1f5)]=function(_0x4cfd15){const _0x837e8a=_0x262028;if(!_0x4cfd15[_0x837e8a(0x29c)])return![];if(!_0x4cfd15[_0x837e8a(0x276)]())return![];const _0x232de3=/<(?:PICKABLE EVENT|PICKUP EVENT)>/i,_0x26d973=/<(?:PICKABLE CHARACTER|PICKUP CHARACTER)>/i,_0x255bb1=/<(?:PICKABLE EVENT|PICKUP EVENT):[ ](.)>/i,_0x21467e=_0x4cfd15['list'](),_0x51ffe5=_0x21467e[_0x837e8a(0x210)];for(let _0x12bfe0=0x0;_0x12bfe0<_0x51ffe5;++_0x12bfe0){let _0x3c1b12=_0x21467e[_0x12bfe0];if([0x6c,0x198]['contains'](_0x3c1b12[_0x837e8a(0x222)])){const _0x2ba91c=_0x3c1b12[_0x837e8a(0x224)][0x0];if(_0x2ba91c[_0x837e8a(0x24d)](_0x232de3)||_0x2ba91c[_0x837e8a(0x24d)](_0x26d973)||_0x2ba91c[_0x837e8a(0x24d)](_0x255bb1))return!![];}}return![];},TSR[_0x262028(0x250)]['Scene_Map_start']=Scene_Map[_0x262028(0x23a)][_0x262028(0x215)],Scene_Map[_0x262028(0x23a)][_0x262028(0x215)]=function(){const _0x449a4d=_0x262028;TSR[_0x449a4d(0x250)]['Scene_Map_start'][_0x449a4d(0x1f1)](this),$gamePlayer[_0x449a4d(0x2b3)](![]),$gamePlayer[_0x449a4d(0x279)](![]);for(const _0x160c36 of $gamePlayer[_0x449a4d(0x27a)]()[_0x449a4d(0x233)]){_0x160c36['setPreventMirror'](![]),_0x160c36[_0x449a4d(0x279)](![]);}},Game_Map[_0x262028(0x23a)][_0x262028(0x21b)]=function(_0x5a685e,_0xdc7938){const _0x806c9=_0x262028,_0xd4792b=TSR[_0x806c9(0x250)][_0x806c9(0x2b2)][0x0],_0x2bcfb9=TSR[_0x806c9(0x250)]['_mirrorInfo'][0x1];return this[_0xd4792b](_0x5a685e-0x1,_0xdc7938)===_0x2bcfb9||this[_0xd4792b](_0x5a685e+0x1,_0xdc7938)===_0x2bcfb9||this[_0xd4792b](_0x5a685e,_0xdc7938)===_0x2bcfb9;},Game_Character['prototype']['checkMirrorTiles']=function(_0x3fe88c,_0xf6f36f){const _0x3fc8df=_0x262028;if(this[_0x3fc8df(0x22e)](_0x3fe88c,_0xf6f36f)){const _0xd1c99b=this[_0x3fc8df(0x2b0)](_0x3fe88c,_0xf6f36f);return this['isNearMirrorTile'](_0x3fe88c,_0xf6f36f,_0xd1c99b);}return![];},Game_Character[_0x262028(0x23a)][_0x262028(0x22e)]=function(_0x43c81e,_0x4bbf9a){const _0x4714c3=_0x262028;return this[_0x4714c3(0x21f)](_0x43c81e,_0x4bbf9a);},Game_Character[_0x262028(0x23a)]['isMirrorColumn']=function(_0x2234b3,_0x4c4c62){const _0x632127=_0x262028;for(let _0x5600f5=_0x4c4c62;_0x5600f5>0x0;_0x5600f5--){if($gameMap[_0x632127(0x21b)](_0x2234b3,_0x5600f5))return!![];}return![];},Game_Character[_0x262028(0x23a)]['isNearMirrorTile']=function(_0xf4b2d9,_0x1ce192,_0x36f50f){const _0x312de8=_0x262028;return this['checkMirrorY'](_0xf4b2d9,_0x1ce192,_0x36f50f)?this[_0x312de8(0x1fd)]=!![]:this[_0x312de8(0x1fd)]=![],this[_0x312de8(0x1fd)];},Game_Character[_0x262028(0x23a)][_0x262028(0x2ae)]=function(_0x25c16b,_0x4edcec,_0x30b22e){const _0x5232ac=_0x262028;for(let _0x466f90=_0x4edcec;_0x466f90>_0x4edcec-_0x30b22e-0x1;_0x466f90--){if($gameMap[_0x5232ac(0x21b)](_0x25c16b,_0x466f90))return!![];}return![];},Game_Character[_0x262028(0x23a)][_0x262028(0x2b0)]=function(_0xdc1213,_0x41defe){const _0x4fb343=_0x262028;this['resetMirrorBottomTop']();for(let _0x4cbc6c=_0x41defe;_0x4cbc6c>0x0;_0x4cbc6c--){if($gameMap[_0x4fb343(0x21b)](_0xdc1213,_0x4cbc6c)){if(!this[_0x4fb343(0x2b6)]())this[_0x4fb343(0x27b)]=_0x4cbc6c;}else{if(!this[_0x4fb343(0x261)]()&&this[_0x4fb343(0x2b6)]()){this[_0x4fb343(0x2ba)]=_0x4cbc6c+0x1;break;}}}return this[_0x4fb343(0x27b)]-this[_0x4fb343(0x2ba)]+0x2;},Game_Character[_0x262028(0x23a)]['bottomMirrorY']=function(){const _0x1d66f5=_0x262028;return this[_0x1d66f5(0x27b)];},Game_Character[_0x262028(0x23a)][_0x262028(0x261)]=function(){const _0x52cbe0=_0x262028;return this[_0x52cbe0(0x2ba)];},Game_Character['prototype'][_0x262028(0x202)]=function(_0x31b5f3,_0x191daa){const _0x201b66=_0x262028;return this[_0x201b66(0x2a8)](_0x31b5f3,_0x191daa);},Game_Character[_0x262028(0x23a)][_0x262028(0x202)]=function(_0x389038,_0x139564){const _0x1f4612=_0x262028;return this[_0x1f4612(0x2a8)](_0x389038,_0x139564);},Game_Character[_0x262028(0x23a)]['isNearReflectTile']=function(_0x514cfc,_0x4d6f4b){const _0x319dfb=_0x262028,_0x23dfcf=$gameMap[_0x319dfb(0x273)](_0x514cfc,0x4),_0x1ad2ed=$gameMap[_0x319dfb(0x273)](_0x514cfc,0x6),_0x3fe3a6=$gameMap[_0x319dfb(0x273)](_0x23dfcf,0x4),_0x5ed9a9=$gameMap['roundXWithDirection'](_0x1ad2ed,0x6);return this[_0x319dfb(0x2ab)](_0x514cfc,_0x4d6f4b)||this[_0x319dfb(0x2ab)](_0x23dfcf,_0x4d6f4b)||this[_0x319dfb(0x2ab)](_0x1ad2ed,_0x4d6f4b)||this[_0x319dfb(0x2ab)](_0x3fe3a6,_0x4d6f4b)||this[_0x319dfb(0x2ab)](_0x5ed9a9,_0x4d6f4b);},Game_Character['prototype'][_0x262028(0x2ab)]=function(_0x37e8fa,_0x53ee66){const _0x49eb5e=_0x262028,_0x55ce06=this[_0x49eb5e(0x290)](_0x37e8fa,_0x53ee66),_0x47a7b1=_0x55ce06?_0x49eb5e(0x216):TSR[_0x49eb5e(0x250)]['_reflectInfo'][0x0],_0x384626=_0x55ce06?parseInt(_0x55ce06[0x0]):TSR[_0x49eb5e(0x250)][_0x49eb5e(0x20e)][0x1];return $gameMap[_0x47a7b1](_0x37e8fa,_0x53ee66)===_0x384626||$gameMap[_0x47a7b1](_0x37e8fa,_0x53ee66-0x1)===_0x384626||$gameMap[_0x47a7b1](_0x37e8fa,_0x53ee66-0x2)===_0x384626||$gameMap[_0x47a7b1](_0x37e8fa,_0x53ee66+0x1)===_0x384626||$gameMap[_0x47a7b1](_0x37e8fa,_0x53ee66+0x2)===_0x384626;},Game_Character['prototype'][_0x262028(0x290)]=function(_0x3fc6ca,_0x2ae3c7){const _0x2ac5fb=_0x262028;for(let _0x595a87=-0x2;_0x595a87<0x2;_0x595a87++){ar=DataManager['getMapMirrorInfos']($gameMap[_0x2ac5fb(0x216)](_0x3fc6ca,_0x2ae3c7+_0x595a87));if(ar)return this[_0x2ac5fb(0x21a)](ar),ar;}return this[_0x2ac5fb(0x21a)](![]),![];},TSR['mirror']['_Game_Character_update']=Game_Character[_0x262028(0x23a)][_0x262028(0x26c)],Game_Character[_0x262028(0x23a)][_0x262028(0x26c)]=function(){const _0x5822e3=_0x262028;TSR['mirror']['_Game_Character_update']['call'](this);if(!this[_0x5822e3(0x283)]()){if(this[_0x5822e3(0x24e)](this['x'],this['y'])&&this[_0x5822e3(0x1f4)]()){this['setMirror'](!![]);if(Imported[_0x5822e3(0x254)]){if(this[_0x5822e3(0x27e)]()&&this[_0x5822e3(0x281)]){const _0x39b054=this[_0x5822e3(0x24c)]();if(!_0x39b054[_0x5822e3(0x2a5)]())_0x39b054[_0x5822e3(0x286)](!![]);}}}if(this[_0x5822e3(0x202)](this['x'],this['y'])&&this[_0x5822e3(0x25c)]()){this[_0x5822e3(0x2a1)](!![]);if(Imported[_0x5822e3(0x254)]){if(this['isPlayer']()&&this[_0x5822e3(0x281)]){const _0x2f777a=this['pickupEvent']();if(!_0x2f777a[_0x5822e3(0x23d)]())_0x2f777a[_0x5822e3(0x2a1)](!![]);}}}}},Game_Character[_0x262028(0x23a)][_0x262028(0x1f4)]=function(){const _0x29f6af=_0x262028;if(this[_0x29f6af(0x245)]&&!this[_0x29f6af(0x203)])return![];return!this[_0x29f6af(0x2a5)]();},Game_Character[_0x262028(0x23a)][_0x262028(0x25c)]=function(){const _0x4deacc=_0x262028;if(this['_memberIndex']&&!this[_0x4deacc(0x203)])return![];return!this['preventReflect']();},Game_Character[_0x262028(0x23a)]['distToBottomMirror']=function(){const _0x2954e1=_0x262028;return this[_0x2954e1(0x28a)]-this[_0x2954e1(0x27b)];},Game_Character[_0x262028(0x23a)][_0x262028(0x1fa)]=function(){return this['_needsMirror'];},Game_Character[_0x262028(0x23a)][_0x262028(0x286)]=function(_0x399129){const _0x357682=_0x262028;this[_0x357682(0x282)]=_0x399129;},Game_Character[_0x262028(0x23a)][_0x262028(0x252)]=function(){const _0x30237e=_0x262028;return this[_0x30237e(0x22c)];},Game_Character[_0x262028(0x23a)]['setReflect']=function(_0x9ac914){this['_needsReflect']=_0x9ac914;},Game_Character[_0x262028(0x23a)][_0x262028(0x21a)]=function(_0x433471){const _0x109a01=_0x262028;this[_0x109a01(0x268)]=_0x433471;},Game_Character[_0x262028(0x23a)][_0x262028(0x23c)]=function(){const _0x9703e7=_0x262028;return this[_0x9703e7(0x268)];},Game_Character['prototype'][_0x262028(0x2a5)]=function(){const _0x5619d3=_0x262028;return this[_0x5619d3(0x274)];},Game_Character[_0x262028(0x23a)]['setPreventMirror']=function(_0x56802e){const _0x1f233a=_0x262028;this[_0x1f233a(0x274)]=_0x56802e;},Game_Character[_0x262028(0x23a)][_0x262028(0x23d)]=function(){return this['_preventReflect'];},Game_Character[_0x262028(0x23a)][_0x262028(0x279)]=function(_0x1a1dca){this['_preventReflect']=_0x1a1dca;},Game_Character[_0x262028(0x23a)]['checkCannotMirrorTag']=function(){const _0x57c3c8=_0x262028;return this[_0x57c3c8(0x2a6)];},Game_Character['prototype']['checkFixMirrorTag']=function(){const _0x14e6ac=_0x262028;return this[_0x14e6ac(0x223)];},Game_Character[_0x262028(0x23a)][_0x262028(0x285)]=function(){const _0x62fff1=_0x262028;return this[_0x62fff1(0x1fd)];},Game_Character[_0x262028(0x23a)][_0x262028(0x2a4)]=function(){this['_bottomMirrorY']=![],this['_topMirrorY']=![];},TSR[_0x262028(0x250)][_0x262028(0x20a)]=Game_Event['prototype']['setupPage'],Game_Event[_0x262028(0x23a)][_0x262028(0x217)]=function(){const _0x5257b3=_0x262028;TSR[_0x5257b3(0x250)]['_Game_Event_setupPage'][_0x5257b3(0x1f1)](this),this[_0x5257b3(0x227)]();},Game_Event['prototype'][_0x262028(0x227)]=function(){const _0x2fe90f=_0x262028;if(!this['page']())return;const _0x48a991=/<(?:CANNOT MIRROR EVENT|NO MIRROR)>/i,_0x282018=/<(?:WALL MIRROR OFFSET|WALL OFFSET):[ ]-*(\d+),[ ]-*(\d+)>/i,_0x410fcc=/<(?:FLOOR MIRROR OFFSET|WATER REFLECT OFFSET):[ ]-*(\d+),[ ]-*(\d+)>/i,_0x562bb8=/<(?:FIX MIRROR IMAGE|FIX IMAGE|FIX MIRROR)>/i,_0x107318=this['list'](),_0xe00630=_0x107318[_0x2fe90f(0x210)];this[_0x2fe90f(0x2a6)]=![],this[_0x2fe90f(0x2aa)]=![],this[_0x2fe90f(0x29b)]=![],this[_0x2fe90f(0x223)]=![];for(let _0x17bc6a=0x0;_0x17bc6a<_0xe00630;++_0x17bc6a){let _0x354f7a=_0x107318[_0x17bc6a];if([0x6c,0x198]['contains'](_0x354f7a[_0x2fe90f(0x222)])){const _0x2333e6=_0x354f7a[_0x2fe90f(0x224)][0x0];if(_0x2333e6['match'](_0x48a991))this[_0x2fe90f(0x2a6)]=!![];else{if(_0x2333e6[_0x2fe90f(0x24d)](_0x282018)){const _0x3276e0=parseInt(_0x2333e6[_0x2fe90f(0x1f8)](_0x2333e6[_0x2fe90f(0x292)](':')+0x1,_0x2333e6[_0x2fe90f(0x292)](','))),_0x2387cd=parseInt(_0x2333e6[_0x2fe90f(0x1f8)](_0x2333e6[_0x2fe90f(0x292)](',')+0x1,_0x2333e6['indexOf']('>')));this[_0x2fe90f(0x2aa)]=[_0x3276e0,_0x2387cd];}else{if(_0x2333e6[_0x2fe90f(0x24d)](_0x410fcc)){const _0x26bda8=parseInt(_0x2333e6[_0x2fe90f(0x1f8)](_0x2333e6['indexOf'](':')+0x1,_0x2333e6['indexOf'](','))),_0xa79f81=parseInt(_0x2333e6[_0x2fe90f(0x1f8)](_0x2333e6['indexOf'](',')+0x1,_0x2333e6[_0x2fe90f(0x292)]('>')));this[_0x2fe90f(0x29b)]=[_0x26bda8,_0xa79f81];}else _0x2333e6[_0x2fe90f(0x24d)](_0x562bb8)&&(this[_0x2fe90f(0x223)]=!![]);}}}}},TSR['mirror'][_0x262028(0x266)]=Spriteset_Map[_0x262028(0x23a)]['createLowerLayer'],Spriteset_Map[_0x262028(0x23a)][_0x262028(0x213)]=function(){const _0x39e3e5=_0x262028;TSR[_0x39e3e5(0x250)]['_Spriteset_Map_createLowerLayer']['call'](this),this[_0x39e3e5(0x269)]();},Spriteset_Map[_0x262028(0x23a)]['createMirrorBackGroundSprites']=function(){const _0x2573ad=_0x262028,_0x2c29ef=DataManager['getMapBackGround']();this['_mirrorBGArray']=[];for(const _0x1b1981 in _0x2c29ef){const _0x45e60e=_0x2c29ef[_0x1b1981][0x0][_0x2573ad(0x243)](),_0x1e657b=_0x2c29ef[_0x1b1981][0x1][_0x2573ad(0x243)](),_0x81f436=parseFloat(_0x2c29ef[_0x1b1981][0x2]),_0x3c76b6=parseFloat(_0x2c29ef[_0x1b1981][0x3]),_0x3375a9=parseFloat(_0x2c29ef[_0x1b1981][0x4]);this[_0x2573ad(0x208)](_0x45e60e,_0x1e657b,_0x81f436,_0x3c76b6,_0x3375a9);}},Spriteset_Map['prototype'][_0x262028(0x208)]=function(_0x3bfea9,_0x44e724,_0x412fc9,_0x586df5,_0x2517e1){const _0x3c3726=_0x262028,_0x4429ea='-'+_0x3bfea9+_0x3c3726(0x277);this[_0x4429ea]=new Sprite(),this[_0x4429ea][_0x3c3726(0x260)]=ImageManager[_0x3c3726(0x247)](_0x44e724),this[_0x4429ea][_0x3c3726(0x278)](0x0,0x0,this[_0x3c3726(0x258)],this[_0x3c3726(0x26f)]),this[_0x4429ea]['_displayX']=_0x412fc9,this[_0x4429ea][_0x3c3726(0x221)]=_0x586df5,this[_0x4429ea]['z']=_0x2517e1,this['_tilemap']['addChild'](this[_0x4429ea]),this[_0x3c3726(0x280)]['push'](this[_0x4429ea]);},TSR[_0x262028(0x250)][_0x262028(0x1f3)]=Spriteset_Map[_0x262028(0x23a)][_0x262028(0x26c)],Spriteset_Map['prototype'][_0x262028(0x26c)]=function(){const _0x361d29=_0x262028;TSR['mirror']['_Spriteset_Map_update'][_0x361d29(0x1f1)](this),this[_0x361d29(0x296)]();},Spriteset_Map[_0x262028(0x23a)][_0x262028(0x296)]=function(){const _0x38578f=_0x262028;for(const _0x4738df in this[_0x38578f(0x280)]){const _0x3ff1ab=this[_0x38578f(0x280)][_0x4738df],_0x131d4d=$gameMap[_0x38578f(0x1f2)](),_0x2133ae=$gameMap['tileHeight']();_0x3ff1ab['x']=_0x3ff1ab[_0x38578f(0x288)]*_0x131d4d-$gameMap[_0x38578f(0x288)]*_0x131d4d,_0x3ff1ab['y']=_0x3ff1ab['_displayY']*_0x2133ae-$gameMap[_0x38578f(0x221)]*_0x2133ae;}},TSR[_0x262028(0x250)][_0x262028(0x27c)]=Sprite_Character[_0x262028(0x23a)][_0x262028(0x253)],Sprite_Character[_0x262028(0x23a)][_0x262028(0x253)]=function(){const _0xbd1887=_0x262028;TSR[_0xbd1887(0x250)][_0xbd1887(0x27c)][_0xbd1887(0x1f1)](this),this['_mirrorSpriteSet']=[],this['_reflectSpriteSet']=[];},TSR[_0x262028(0x250)]['_Sprite_Character_update']=Sprite_Character[_0x262028(0x23a)][_0x262028(0x26c)],Sprite_Character[_0x262028(0x23a)][_0x262028(0x26c)]=function(){const _0x26553e=_0x262028;TSR[_0x26553e(0x250)][_0x26553e(0x28c)]['call'](this),this[_0x26553e(0x232)]();},Sprite_Character[_0x262028(0x23a)][_0x262028(0x232)]=function(){const _0x23a5f6=_0x262028;this[_0x23a5f6(0x259)](),this[_0x23a5f6(0x26a)][_0x23a5f6(0x210)]>0x0&&(!this[_0x23a5f6(0x26a)][0x0][_0x23a5f6(0x293)]()&&(this['parent']['removeChild'](this[_0x23a5f6(0x26a)][0x0]),this[_0x23a5f6(0x26a)][_0x23a5f6(0x23f)](),this['_character'][_0x23a5f6(0x2b3)](![]),this[_0x23a5f6(0x262)][_0x23a5f6(0x2a4)](),this['_character'][_0x23a5f6(0x1fd)]=![])),this['setupReflect'](),this[_0x23a5f6(0x2a9)]['length']>0x0&&(!this[_0x23a5f6(0x2a9)][0x0]['isPlaying']()&&(this['parent'][_0x23a5f6(0x228)](this[_0x23a5f6(0x2a9)][0x0]),this[_0x23a5f6(0x2a9)][_0x23a5f6(0x23f)](),this[_0x23a5f6(0x262)][_0x23a5f6(0x279)](![])));},Sprite_Character[_0x262028(0x23a)]['setupMirror']=function(){const _0x24ee1d=_0x262028;this[_0x24ee1d(0x262)][_0x24ee1d(0x1fa)]()&&(this[_0x24ee1d(0x262)]['setMirror'](![]),this[_0x24ee1d(0x262)][_0x24ee1d(0x2b3)](!![]),this['startMirror']());},Sprite_Character[_0x262028(0x23a)][_0x262028(0x239)]=function(){const _0x2c7170=_0x262028,_0x58dce6=this[_0x2c7170(0x240)]();this[_0x2c7170(0x26a)][_0x2c7170(0x256)](_0x58dce6);},Sprite_Character[_0x262028(0x23a)]['createMirrorSprite']=function(){const _0x18f084=_0x262028,_0x154e56=new Sprite_Mirror();return _0x154e56['x']=this[_0x18f084(0x262)]['screenX'](),_0x154e56['y']=this[_0x18f084(0x262)]['screenY'](),_0x154e56['setup'](this,this[_0x18f084(0x262)]),this['parent']['addChild'](_0x154e56),_0x154e56;},Sprite_Character[_0x262028(0x23a)][_0x262028(0x267)]=function(){const _0x3644fb=_0x262028;this['_character']['needsReflect']()&&(this['_character'][_0x3644fb(0x2a1)](![]),this['_character'][_0x3644fb(0x279)](!![]),this['startReflect']());},Sprite_Character[_0x262028(0x23a)]['startReflect']=function(){const _0x420008=_0x262028,_0x173bea=this[_0x420008(0x2ad)]();this['_reflectSpriteSet'][_0x420008(0x256)](_0x173bea);},Sprite_Character[_0x262028(0x23a)][_0x262028(0x2ad)]=function(){const _0x53cc0c=_0x262028,_0x92eed0=$gameMap[_0x53cc0c(0x1f2)](),_0x5a8800=new Sprite_Reflect();return _0x5a8800['x']=-_0x92eed0,_0x5a8800['y']=-_0x92eed0,_0x5a8800[_0x53cc0c(0x2ac)](this,this[_0x53cc0c(0x262)]),this[_0x53cc0c(0x2b4)][_0x53cc0c(0x219)](_0x5a8800),_0x5a8800;});function Sprite_Mirror(){const _0x31a78c=_0x262028;this[_0x31a78c(0x263)]['apply'](this,arguments);}Sprite_Mirror[_0x262028(0x23a)]=Object[_0x262028(0x231)](Sprite[_0x262028(0x23a)]),Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x271)]=Sprite_Mirror,Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x263)]=function(){const _0x1c8e1f=_0x262028;Sprite['prototype'][_0x1c8e1f(0x263)][_0x1c8e1f(0x1f1)](this),this[_0x1c8e1f(0x253)]();},Sprite_Mirror[_0x262028(0x23a)]['initMembers']=function(){const _0x478744=_0x262028;this[_0x478744(0x237)]['x']=0.5,this[_0x478744(0x237)]['y']=0x0,this['z']=-0.5,this[_0x478744(0x299)]=TSR[_0x478744(0x250)]['_wallOffsetX'],this[_0x478744(0x249)]=TSR[_0x478744(0x250)][_0x478744(0x218)];},Sprite_Mirror[_0x262028(0x23a)]['setup']=function(_0x5a09b2,_0x424dbd){const _0xda9353=_0x262028,_0x2f83ea=_0x424dbd[_0xda9353(0x2aa)];_0x2f83ea&&(this['_offsetX']=_0x2f83ea[0x0],this[_0xda9353(0x249)]=_0x2f83ea[0x1]),this[_0xda9353(0x1fc)]=_0x5a09b2,this['_character']=_0x424dbd,this[_0xda9353(0x287)]=_0x424dbd['_characterName'],this[_0xda9353(0x1fb)]=_0x424dbd['_characterIndex'],_0x424dbd['_scale']&&(this[_0xda9353(0x26e)]['x']=_0x424dbd[_0xda9353(0x206)],this[_0xda9353(0x26e)]['y']=_0x424dbd[_0xda9353(0x206)],this['_offsetX']*=_0x424dbd['_scale'],this[_0xda9353(0x249)]*=_0x424dbd['_scale']),_0x424dbd[_0xda9353(0x205)]>0x0?(this['_tileId']=_0x424dbd[_0xda9353(0x205)],this['bitmap']=this[_0xda9353(0x20c)](this['_tileId']),this['updateTileFrame']()):(this[_0xda9353(0x260)]=ImageManager[_0xda9353(0x294)](this['_characterName']),this[_0xda9353(0x25a)]()),this[_0xda9353(0x291)]();},Sprite_Mirror[_0x262028(0x23a)]['distBottom']=function(){const _0x5efb01=_0x262028,_0x58daf7=this[_0x5efb01(0x262)][_0x5efb01(0x29e)]()*$gameMap[_0x5efb01(0x1f2)]();return _0x58daf7;},Sprite_Mirror['prototype']['update']=function(){const _0xdd3b99=_0x262028;Sprite[_0xdd3b99(0x23a)][_0xdd3b99(0x26c)]['call'](this),this[_0xdd3b99(0x262)]['tileId']()>0x0?this[_0xdd3b99(0x22b)]():this[_0xdd3b99(0x25a)](),this[_0xdd3b99(0x291)](),this[_0xdd3b99(0x225)]=!this[_0xdd3b99(0x262)][_0xdd3b99(0x28e)]()&&this[_0xdd3b99(0x204)]();},Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x20c)]=function(_0x3ca48b){const _0x1715e8=_0x262028,_0xa1f535=$gameMap[_0x1715e8(0x2a2)](),_0x1ac755=0x5+Math[_0x1715e8(0x1ff)](_0x3ca48b/0x100);return ImageManager[_0x1715e8(0x265)](_0xa1f535['tilesetNames'][_0x1ac755]);},Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x22b)]=function(){const _0x57f7fe=_0x262028,_0x11f47c=this[_0x57f7fe(0x205)],_0x3194d4=$gameMap[_0x57f7fe(0x1f2)](),_0x22233d=$gameMap[_0x57f7fe(0x270)](),_0x1ec92a=(Math[_0x57f7fe(0x1ff)](_0x11f47c/0x80)%0x2*0x8+_0x11f47c%0x8)*_0x3194d4,_0x40a182=Math['floor'](_0x11f47c%0x100/0x8)%0x10*_0x22233d;this[_0x57f7fe(0x278)](_0x1ec92a,_0x40a182,_0x3194d4,_0x22233d);},Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x25a)]=function(){const _0x2d0fac=_0x262028,_0x166b3b=this[_0x2d0fac(0x262)][_0x2d0fac(0x1fb)];let _0x536199=this[_0x2d0fac(0x262)][_0x2d0fac(0x25f)]();!this[_0x2d0fac(0x262)][_0x2d0fac(0x21c)]&&!this[_0x2d0fac(0x262)][_0x2d0fac(0x27f)]()&&(_0x536199=this[_0x2d0fac(0x262)][_0x2d0fac(0x25f)]()===0x2||this[_0x2d0fac(0x262)][_0x2d0fac(0x25f)]()===0x8?0xa-this[_0x2d0fac(0x262)]['direction']():this[_0x2d0fac(0x262)][_0x2d0fac(0x25f)]());const _0x4955bc=this[_0x2d0fac(0x260)][_0x2d0fac(0x258)]/0xc,_0x23c2da=this[_0x2d0fac(0x260)][_0x2d0fac(0x26f)]/0x8,_0x30d9f4=(_0x166b3b%0x4*0x3+this[_0x2d0fac(0x262)][_0x2d0fac(0x27d)]())*_0x4955bc,_0x47f564=(Math[_0x2d0fac(0x1ff)](_0x166b3b/0x4)*0x4+(_0x536199-0x2)/0x2)*_0x23c2da;this[_0x2d0fac(0x278)](_0x30d9f4,_0x47f564,_0x4955bc,_0x23c2da);},Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x291)]=function(){const _0x337546=_0x262028,_0x1d128b=this[_0x337546(0x249)]-this[_0x337546(0x201)]()*0x2;if(Imported['TSR_MoveEvent']){let _0x40df82=0x2*(this[_0x337546(0x1fc)]['y']-this[_0x337546(0x262)][_0x337546(0x229)]());if(this[_0x337546(0x262)][_0x337546(0x29d)]()||this['_character'][_0x337546(0x212)]()||this[_0x337546(0x262)][_0x337546(0x242)]())this['x']=this[_0x337546(0x1fc)]['x']+this[_0x337546(0x299)],this['y']=this[_0x337546(0x1fc)]['y']-_0x40df82+_0x1d128b;else{const _0x4baa0d=$gamePlayer[_0x337546(0x25f)](),_0x32e432=this[_0x337546(0x262)][_0x337546(0x20b)](),_0x26c301=_0x32e432?_0x4baa0d===0x4||_0x4baa0d===0x6?0xc:0x7:0x0;this['x']=this['_character'][_0x337546(0x241)]()+this[_0x337546(0x299)],this['y']=this[_0x337546(0x262)]['screenY']()+_0x1d128b-_0x26c301*0x2;}}else this['x']=this[_0x337546(0x262)][_0x337546(0x241)]()+this[_0x337546(0x299)],this['y']=this[_0x337546(0x262)]['screenY']()+_0x1d128b;},Sprite_Mirror[_0x262028(0x23a)][_0x262028(0x204)]=function(){const _0x34a8b7=_0x262028;return this[_0x34a8b7(0x287)]===this['_character'][_0x34a8b7(0x211)]()&&this[_0x34a8b7(0x1fb)]===this[_0x34a8b7(0x262)]['characterIndex']()||(this[_0x34a8b7(0x2a7)]===$gameMap['tilesetId']()||this['_tileId']===this[_0x34a8b7(0x262)][_0x34a8b7(0x26d)]());},Sprite_Mirror[_0x262028(0x23a)]['isPlaying']=function(){const _0x1892e5=_0x262028;return this[_0x1892e5(0x262)][_0x1892e5(0x24e)](this[_0x1892e5(0x262)]['x'],this[_0x1892e5(0x262)]['y'])&&this[_0x1892e5(0x204)]();};function Sprite_Reflect(){const _0x56434d=_0x262028;this[_0x56434d(0x263)][_0x56434d(0x251)](this,arguments);}Sprite_Reflect[_0x262028(0x23a)]=Object[_0x262028(0x231)](Sprite[_0x262028(0x23a)]),Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x271)]=Sprite_Reflect,Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x263)]=function(){const _0x5cba2e=_0x262028;Sprite['prototype'][_0x5cba2e(0x263)]['call'](this),this[_0x5cba2e(0x253)]();},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x253)]=function(){const _0x373d35=_0x262028;this[_0x373d35(0x237)]['x']=0.5,this['anchor']['y']=0.5,this['z']=-0.6;},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x24b)]=function(_0x4cd7f3){const _0x25eee0=_0x262028;_0x4cd7f3?(this['_offsetX']=parseInt(_0x4cd7f3[0x1]),this[_0x25eee0(0x249)]=parseInt(_0x4cd7f3[0x2]),this['_angle']=parseFloat(_0x4cd7f3[0x3]),this[_0x25eee0(0x275)]=parseFloat(_0x4cd7f3[0x4]),this[_0x25eee0(0x28d)]=parseInt(_0x4cd7f3[0x5]),this[_0x25eee0(0x29a)]=_0x4cd7f3[0x6]):(this[_0x25eee0(0x299)]=TSR[_0x25eee0(0x250)][_0x25eee0(0x2b1)],this[_0x25eee0(0x249)]=TSR[_0x25eee0(0x250)]['_floorOffsetY'],this['_angle']=TSR[_0x25eee0(0x250)][_0x25eee0(0x25d)],this[_0x25eee0(0x275)]=TSR[_0x25eee0(0x250)][_0x25eee0(0x275)],this[_0x25eee0(0x28d)]=TSR[_0x25eee0(0x250)][_0x25eee0(0x248)],this[_0x25eee0(0x29a)]=TSR[_0x25eee0(0x250)][_0x25eee0(0x29a)]);},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x2ac)]=function(_0x54293b,_0x1b3172){const _0x42eb36=_0x262028;this[_0x42eb36(0x1fc)]=_0x54293b;const _0x1eb2bc=_0x1b3172[_0x42eb36(0x29b)];this[_0x42eb36(0x2b2)]=_0x1b3172['currentMirrorInfo'](),this[_0x42eb36(0x24b)](this[_0x42eb36(0x2b2)]),this['rotation']=this['_angle']*0x5a*Math['PI']/0xb4,this[_0x42eb36(0x25e)]=new PIXI[(_0x42eb36(0x200))][(_0x42eb36(0x28b))](),this[_0x42eb36(0x25e)][_0x42eb36(0x226)]=this[_0x42eb36(0x275)],this[_0x42eb36(0x200)]=[this[_0x42eb36(0x25e)]],_0x1eb2bc&&(this['_offsetX']=_0x1eb2bc[0x0],this[_0x42eb36(0x249)]=_0x1eb2bc[0x1]),_0x1b3172[_0x42eb36(0x206)]&&(this['scale']['x']=_0x1b3172[_0x42eb36(0x206)],this['scale']['y']=_0x1b3172[_0x42eb36(0x206)],this['_offsetX']*=_0x1b3172[_0x42eb36(0x206)],this[_0x42eb36(0x249)]*=_0x1b3172[_0x42eb36(0x206)]),this[_0x42eb36(0x24a)]=this[_0x42eb36(0x26e)]['x'],this[_0x42eb36(0x209)]=this['scale']['y'],this[_0x42eb36(0x262)]=_0x1b3172,this[_0x42eb36(0x287)]=_0x1b3172['_characterName'],this[_0x42eb36(0x1fb)]=_0x1b3172[_0x42eb36(0x1fb)],_0x1b3172['_tileId']>0x0?(this[_0x42eb36(0x205)]=_0x1b3172[_0x42eb36(0x205)],this[_0x42eb36(0x260)]=this['tilesetBitmap'](this[_0x42eb36(0x205)]),this[_0x42eb36(0x22b)]()):(this[_0x42eb36(0x260)]=ImageManager[_0x42eb36(0x294)](this[_0x42eb36(0x287)]),this[_0x42eb36(0x25a)]()),this[_0x42eb36(0x2af)]=0x0,this['updateCharacterMove']();},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x26c)]=function(){const _0x496a5d=_0x262028;Sprite['prototype']['update'][_0x496a5d(0x1f1)](this);this[_0x496a5d(0x262)][_0x496a5d(0x26d)]()>0x0?this[_0x496a5d(0x22b)]():this[_0x496a5d(0x25a)]();this[_0x496a5d(0x291)]();if(this[_0x496a5d(0x29a)])this['updateScale']();this[_0x496a5d(0x225)]=!this['_character'][_0x496a5d(0x28e)]()&&this[_0x496a5d(0x204)]();},Sprite_Reflect[_0x262028(0x23a)]['tilesetBitmap']=function(_0x3cc588){const _0x419f15=_0x262028,_0x199d8a=$gameMap['tileset'](),_0x389dd4=0x5+Math[_0x419f15(0x1ff)](_0x3cc588/0x100);return ImageManager['loadTileset'](_0x199d8a[_0x419f15(0x23e)][_0x389dd4]);},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x22b)]=function(){const _0x35dc03=_0x262028,_0x4a61e=this[_0x35dc03(0x205)],_0x4b4c6b=$gameMap[_0x35dc03(0x1f2)](),_0x23ea3a=$gameMap[_0x35dc03(0x270)](),_0xfab114=(Math[_0x35dc03(0x1ff)](_0x4a61e/0x80)%0x2*0x8+_0x4a61e%0x8)*_0x4b4c6b,_0x144cd2=Math[_0x35dc03(0x1ff)](_0x4a61e%0x100/0x8)%0x10*_0x23ea3a;this[_0x35dc03(0x278)](_0xfab114,_0x144cd2,_0x4b4c6b,_0x23ea3a);},Sprite_Reflect[_0x262028(0x23a)]['updateCharacterFrame']=function(){const _0x7b013f=_0x262028,_0x451289=this[_0x7b013f(0x262)][_0x7b013f(0x1fb)];let _0x1710d6=this[_0x7b013f(0x262)][_0x7b013f(0x25f)]();!this[_0x7b013f(0x262)][_0x7b013f(0x21c)]&&(this[_0x7b013f(0x25d)]<=0x1&&this[_0x7b013f(0x25d)]>=-0x1?_0x1710d6=_0x1710d6===0x2||_0x1710d6===0x8?0xa-_0x1710d6:_0x1710d6:_0x1710d6=_0x1710d6===0x4||_0x1710d6===0x6?0xa-_0x1710d6:_0x1710d6);const _0x4c3629=this[_0x7b013f(0x260)][_0x7b013f(0x258)]/0xc,_0x51c077=this[_0x7b013f(0x260)][_0x7b013f(0x26f)]/0x8,_0x47867c=(_0x451289%0x4*0x3+this[_0x7b013f(0x262)][_0x7b013f(0x27d)]())*_0x4c3629,_0xe3f987=(Math[_0x7b013f(0x1ff)](_0x451289/0x4)*0x4+(_0x1710d6-0x2)/0x2)*_0x51c077;this['setFrame'](_0x47867c,_0xe3f987,_0x4c3629,_0x51c077);},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x291)]=function(){const _0x1f7fbc=_0x262028;if(Imported[_0x1f7fbc(0x254)]){this['updateContainerZ'](this['_character']['_eventId']);if(this[_0x1f7fbc(0x262)][_0x1f7fbc(0x29d)]()||this[_0x1f7fbc(0x262)]['pullDist']()||this[_0x1f7fbc(0x262)][_0x1f7fbc(0x242)]()){this['x']=this[_0x1f7fbc(0x1fc)]['x']+this[_0x1f7fbc(0x299)],this['y']=this[_0x1f7fbc(0x1fc)]['y']+this[_0x1f7fbc(0x249)];;}else this['x']=this[_0x1f7fbc(0x262)]['screenX']()+this['_offsetX'],this['y']=this[_0x1f7fbc(0x262)]['screenY']()+this['_offsetY'];}else this['x']=this[_0x1f7fbc(0x262)][_0x1f7fbc(0x241)]()+this[_0x1f7fbc(0x299)],this['y']=this[_0x1f7fbc(0x262)]['screenY']()+this[_0x1f7fbc(0x249)];},Sprite_Reflect[_0x262028(0x23a)]['updateContainerZ']=function(_0x2cd86a){const _0x1ea60a=_0x262028,_0x1ff35f=$gamePlayer;if(_0x1ff35f[_0x1ea60a(0x29f)](_0x2cd86a)){let _0x43a8db;this[_0x1ea60a(0x25d)]<=0x1&&this[_0x1ea60a(0x25d)]>=-0x1?_0x43a8db=0x8:_0x43a8db=0x2,_0x1ff35f[_0x1ea60a(0x25f)]()===_0x43a8db?this['z']=-0.5:this['z']=-0.7;}},Sprite_Reflect['prototype']['updateScale']=function(){const _0x59ded2=_0x262028;this[_0x59ded2(0x2af)]++,!this[_0x59ded2(0x28f)]?this[_0x59ded2(0x26e)]['x']<this[_0x59ded2(0x24a)]*1.05?(this['scale']['x']+=0.005,this['scale']['y']-=0.002):this[_0x59ded2(0x28f)]=!![]:this[_0x59ded2(0x26e)]['x']>this[_0x59ded2(0x24a)]*0.95?(this['scale']['x']-=0.005,this['scale']['y']+=0.002):this[_0x59ded2(0x28f)]=![];},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x204)]=function(){const _0x403755=_0x262028;return this[_0x403755(0x287)]===this['_character']['characterName']()&&this[_0x403755(0x1fb)]===this[_0x403755(0x262)][_0x403755(0x295)]()||(this[_0x403755(0x2a7)]===$gameMap[_0x403755(0x289)]()||this['_tileId']===this['_character'][_0x403755(0x26d)]());},Sprite_Reflect[_0x262028(0x23a)][_0x262028(0x293)]=function(){const _0xe9c416=_0x262028;return this[_0xe9c416(0x262)][_0xe9c416(0x202)](this[_0xe9c416(0x262)]['x'],this[_0xe9c416(0x262)]['y'])&&this[_0xe9c416(0x2b2)][0x0]===this[_0xe9c416(0x262)][_0xe9c416(0x23c)]()[0x0]&&this[_0xe9c416(0x204)]();};
})();

//==== END ======================================================================
//===============================================================================
